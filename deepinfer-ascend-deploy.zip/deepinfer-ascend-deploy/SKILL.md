---
name: deepinfer-ascend-deploy
description: 在 Ascend 950DT 上构建、部署和测试 DeepInfer DeepSeek V4.1，处理 GCC14/bisheng、DeepEP 多端点、FlashMLA 核数、Engram 显存和普通 MoE 回退问题，并运行 GSM8K 可配置离线性能测试。适用于该仓库和经核验的硬件组合，不将这些补丁通用于所有 Ascend 型号。
---

# DeepInfer Ascend 构建、部署与验证

将本 skill 作为带版本约束的复现包使用。已验证的是 8×Ascend950DT、DeepSeek-V4.1-Flash-1017、指定主仓及子模块提交加本包补丁；不是任意新版本的一键通用修复。

## 按任务加载

1. 首次部署：读 [环境与镜像](references/environment.md)，核对硬件、镜像 digest、宿主驱动、CANN、模型及共享内存。镜像标签不代表容器内后续安装已包含在镜像中。
2. 构建或移植：读 [构建与部署步骤](references/build-deploy.md)，使用 `assets/revisions.txt` 和 `assets/patches/`；先检查补丁适用性再应用。工具链文件必须放在目标仓库 `scripts/toolchain/`。
3. 编译失败、算子报错、OOM 或通信异常：按 [问题与原因索引](references/troubleshooting.md) 定位；每项附源文件、修复边界和验证方法。不要用删除断言替代语义修复。
4. 数值验证和离线推理：读 [验证流程](references/validation.md)。通信更改验证共享端点和多端点；内核更改验证数值，不只验证能启动。
5. 性能测试：读 [脚本说明及指标](references/performance.md)，运行 `scripts/run_benchmark_suite.py`，或自定义输入、输出、请求总数与最大并发。历史结果见 [已验证报告](references/verified-results.md)。

## 必须保留的工程约束

- 显式区分“上游基线”“本地补丁”“已安装二进制”；改了源码却未重编子模块不会生效。运行时 DeepJIT 也必须获得 GCC14 和兼容头路径。
- 950DT 实测 28 AIC / 56 AIV。FlashMLA 启动 grid 与工作步长一起改；MegaMoE 的 32 核调度不能只改一个常量，当前使用普通 DeepEP + grouped GEMM。
- 多端点按 `(AIV, peer)` 建队列并路由，不伪造共享 EID。Engram 的 UBMEM-only 分支不分配不必要的 CTP 队列。
- `DEEPINFER_ASCEND_ENGRAM_CPU_STAGING=1` 只减少加载期重复 NPU 表，不等于 vLLM 的运行期 CPU offload。
- `hccl_rootinfo.json` 属于本机通信拓扑，不能复制本包历史机器 EID 当作其他机器配置。本包不分发历史拓扑文件和 SSH 密码。
- 记录完整输入/输出 token 数；长上下文失败不能通过悄悄缩短请求来形成“成功”结果。
- 当前用户明确要求保留其他服务时，等待卡空闲；该 skill 不授予停止其他任务的权限。确认卡空闲、留存 NPU 进程快照后再独占测试。

## 快速入口

在已核对版本的目标仓库上：

```bash
python /path/to/deepinfer-ascend-deploy/scripts/apply_bundle.py --repo /path/to/DeepInfer
# 默认只检查。确认输出适用后执行：
python /path/to/deepinfer-ascend-deploy/scripts/apply_bundle.py --repo /path/to/DeepInfer --apply
cd /path/to/DeepInfer
bash scripts/build_ascend_local.sh 2>&1 | tee build.log
bash scripts/run_offline_ascend_36.sh
python scripts/run_benchmark_suite.py
```

`apply_bundle.py` 不安装系统包、不修改系统头文件、不删除构建目录。它校验提交及补丁，应用到目标仓库并复制本包脚本；同名不同内容的脚本需要显式 `--overwrite-scripts`，覆盖前备份。

## 证据状态与交付

截止本包核验日 2026-10-26：完整构建、FlashMLA 24+48 数值用例、稀疏 MQA 4 用例、DeepEP 多端点模型尺寸及共享端点回归、固定批 200 请求 4K/2K 离线性能已有历史证据。详见 validation。

新的三组闭环测试（400/200、48/12、32/8）脚本已部署并通过 5 项 CPU 测试，但因现有 vLLM 服务占用设备仍等待上机，不能将固定批结果填入这些行。skill 编写期间仅采集只读环境/源码信息，没有停止服务、重建库或占用 NPU 进行验证。

交付需包含环境版本、补丁校验结果、构建日志、数值测试退出码、实际请求记录、CSV/JSON 指标、HBM/进程采样、JIT 编译干扰，以及失败项和未验证项。任何性能百分比都应注明是 kernel 累加还是端到端时间。
