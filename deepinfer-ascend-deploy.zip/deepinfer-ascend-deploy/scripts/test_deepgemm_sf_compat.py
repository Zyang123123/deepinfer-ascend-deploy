"""Exact SF-layout checks using the upstream CPU-independent reference."""
import sys
from pathlib import Path
from itertools import product
import torch
import torch_npu
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'vendor/DeepGEMM-Ascend/tests'))
from test_layout import make_layout_case, check_layout
from generators import GemmType, Major

torch.manual_seed(17)
torch.npu.set_device(0)
count = 0
for dtype, major, gran, batches in product((torch.float32, torch.int16), (Major.K, Major.MN), (1,32,128), (1,2)):
    kind = GemmType.Normal if batches == 1 else GemmType.Batched
    # Ragged MN exercises padding; the second shape matches the model's hidden width.
    for mn,k in ((513,7296),(5120,5120)):
        sf,run,expected = make_layout_case((kind,dtype,major,mn,k,gran,batches,256,()))
        out = run()
        torch.npu.synchronize()
        check_layout(out,expected)
        count += 1
        print(f'PASS {count}: dtype={dtype} major={major} gran={gran} batches={batches} mn={mn} k={k}',flush=True)
print(f'DEEPGEMM_SF_COMPAT_PASS cases={count}',flush=True)
