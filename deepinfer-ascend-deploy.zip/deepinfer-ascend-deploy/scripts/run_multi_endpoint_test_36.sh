#!/usr/bin/env bash
set -eo pipefail
cd "${DEEPINFER_ROOT:-$(dirname "$0")/..}"
source /usr/local/Ascend/cann/set_env.sh
source /opt/openEuler/gcc-toolset-14/enable
export PATH="$PWD/scripts/toolchain:$PATH"
python scripts/toolchain/prepare_headers.py
export DG_BISHENG_GCC_TOOLCHAIN=/opt/openEuler/gcc-toolset-14/root/usr
export DG_BISHENG_COMPAT_INCLUDE="$PWD/build/bisheng-gcc14-compat"
export DEEPINFER_ACCELERATOR=ascend
export ASCEND_LOCAL_COMM_RES='{"version":"1.3"}'
export HCCL_OP_EXPANSION_MODE=CCU_SCHED
export HCCL_SOCKET_IFNAME="${HCCL_SOCKET_IFNAME:-enp34s0f1}" GLOO_SOCKET_IFNAME="${GLOO_SOCKET_IFNAME:-$HCCL_SOCKET_IFNAME}"
export HCCL_IF_IP="${HCCL_IF_IP:-192.168.45.36}" HCCL_CONNECT_TIMEOUT=180
export OMP_NUM_THREADS=4
python -u "$@"
