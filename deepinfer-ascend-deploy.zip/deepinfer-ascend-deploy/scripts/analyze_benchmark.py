#!/usr/bin/env python3
"""Recompute benchmark metrics and summarize the separate Ascend kernel trace."""
import argparse
import csv
import json
import subprocess
from collections import defaultdict
from pathlib import Path

from benchmark_4k2k import aggregate, save


def category(name):
    name = name.lower()
    if "dispatch" in name or "combine" in name:
        return "MoE dispatch/combine"
    if ("grouped" in name or "gemmtypee1e" in name) and ("gemm" in name or "matmul" in name):
        return "MoE grouped GEMM"
    if "engram" in name:
        return "Engram"
    if "mqa" in name or "mla" in name or "attn" in name or "attention" in name or "flash" in name or "topk" in name:
        return "Attention / index"
    if "gemm" in name or "matmul" in name:
        return "Other GEMM"
    if "barrier" in name or "hccl" in name or "notify" in name:
        return "Other communication / sync"
    return "Other"


def analyze(result_dir):
    config = json.loads((result_dir / "config.json").read_text())
    config["result_dir"] = result_dir
    aggregate(argparse.Namespace(**config))
    rank_data = [json.loads(p.read_text()) for p in sorted(result_dir.glob("measure-rank*.json"))]
    requests = [r for d in rank_data for r in d["request_records"]]
    # Steady overlap window: every request has a first token and none has finished.
    since = max(r["first_token"] for r in requests)
    until = min(r["completed"] for r in requests)
    rows = [r for p in result_dir.glob("arrivals-rank*.csv") for r in csv.DictReader(p.open())]
    tokens = sum(int(r["output_tokens"]) for r in rows if since < float(r["timestamp"]) < until)
    running_by_step = defaultdict(int)
    for row in rows:
        running_by_step[int(row["step"])] += int(row["running"])
    overlap = {"start": since, "end": until, "duration_seconds": max(0, until-since),
               "output_tokens": tokens,
               "tokens_per_second": tokens/(until-since) if until > since else None,
               "note": "All 200 requests have emitted first token, none completed; boundary step batches excluded."}
    grouped = defaultdict(lambda: [0, 0.0])
    sources = []
    for prof_dir in sorted((result_dir / "profile").rglob("PROF_*")):
        if not prof_dir.is_dir() or list(prof_dir.rglob("op_summary*.csv")):
            continue
        # CANN 9.2 raw data can be valid even if torch_npu's automatic parser fails.
        with (result_dir / "msprof_export.log").open("a") as log:
            subprocess.run(["bash", "-c", 'source /usr/local/Ascend/cann/set_env.sh; exec msprof --export=on --type=text --output="$1"',
                            "msprof-export", str(prof_dir)], stdout=log, stderr=subprocess.STDOUT, check=True)
    # NPU profiler exports task durations in microseconds. Match columns explicitly.
    for path in sorted((result_dir / "profile").rglob("op_summary*.csv")):
        sources.append(str(path))
        for row in csv.DictReader(path.open(encoding="utf-8-sig")):
            name = row.get("Op Name") or row.get("Name")
            duration_key = next((k for k in row if k.lower().replace(" ", "") in
                                 ("taskduration(us)", "duration(us)", "duration(μs)")), None)
            if not name or not duration_key:
                raise ValueError(f"Unrecognized profiler columns: {list(row)}")
            grouped[name][0] += 1
            grouped[name][1] += float(row[duration_key])
    if config.get("profile_steps", 0) and not grouped:
        raise RuntimeError("Measurement metrics saved, but no NPU kernel durations were exported; inspect profiler logs")
    by_category = defaultdict(lambda: [0, 0.0])
    top = []
    total_us = sum(v[1] for v in grouped.values())
    for name, (count, us) in sorted(grouped.items(), key=lambda item: item[1][1], reverse=True):
        cat = category(name)
        by_category[cat][0] += count
        by_category[cat][1] += us
        top.append(dict(name=name, category=cat, count=count, total_ms=us/1000,
                        mean_us=us/count, share_of_summed_kernel_time=us/total_us))
    report = dict(full_concurrency_decode_window=overlap,
                  max_running_requests=sum(max(int(r["running"]) for r in csv.DictReader(p.open()))
                                           for p in result_dir.glob("arrivals-rank*.csv")),
                  max_running_at_matching_step=max(running_by_step.values()),
                  profile_sources=sources,
                  profile_note="Rank 0, separate diagnostic run. Kernel times may overlap; sums are NOT wall-time percentages. Name-based groups are heuristic.",
                  kernel_total_ms=total_us/1000,
                  kernel_categories={k: dict(count=v[0], total_ms=v[1]/1000,
                      share_of_summed_kernel_time=v[1]/total_us) for k,v in by_category.items()},
                  top_kernels=top)
    save(result_dir / "analysis.json", report)
    print(json.dumps({**report, "top_kernels": top[:20]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_dir", type=Path)
    analyze(parser.parse_args().result_dir.resolve())
