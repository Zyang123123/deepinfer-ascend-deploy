"""Focused numerical regression using upstream references and tolerances."""
import argparse
import itertools
import json
from pathlib import Path
import runpy
import sys

parser = argparse.ArgumentParser()
parser.add_argument("suite", choices=["select", "prefill", "decode"])
parser.add_argument("--list", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
if args.suite == "select":
    cases = [dict(batch_size=b, vocab_size=v, topk=k, sorted_index=si,
                  return_value=rv, enable_end_position=edge,
                  enable_output_idx_offset=edge)
             for (b,v,k), si, rv, edge in itertools.product(
                 [(1,1602,512), (7,32768,1024), (19,65536,4096)],
                 [False,True], [False,True], [False,True])]
elif args.suite == "prefill":
    cases = [dict(s_q=q, s_kv=1024, topk=k, h_q=64,
                  have_attn_sink=sink, have_topk_length=var)
             for q,k,sink,var in itertools.product([1,17,65], [128,576],
                                                    [False,True], [False,True])]
else:
    cases = [dict(b=b, h_q=64, s_q=1, h_kv=1, s_kv=1024,
                  is_varlen=var, topk=128, enable_attn_sink=sink,
                  extra_format=extra)
             for b,var,sink,extra in itertools.product([1,4,29,65], [False,True],
                                                       [False,True], [None,"fp8","fp4"])]
if args.list:
    print(json.dumps({"suite":args.suite, "count":len(cases), "cases":cases}, indent=2))
    sys.exit(0)

import torch
import torch_npu
folder = root / "vendor" / ("DeepSelect" if args.suite == "select" else "FlashMLA") / "tests"
sys.path.insert(0, str(folder))
import kernelkit as kk
import lib
assert kk.is_on_ascend_platform()
torch.npu.set_device(0)
torch.set_default_device("npu:0")
if args.suite != "select":
    torch.set_default_dtype(torch.bfloat16)
    torch.set_float32_matmul_precision("high")
filename = {"select":"test.py", "prefill":"test-sparse-prefill.py", "decode":"test-sparse-decode.py"}[args.suite]
ns = runpy.run_path(str(folder / filename))
passed = 0
for i, spec in enumerate(cases):
    kk.set_random_seed(1000+i)
    spec = dict(spec, seed=1000+i, num_runs=0, check_correctness=True)
    if args.suite == "select":
        p = lib.TestParam(**spec, sorted_value=False, dtype=torch.bfloat16,
                          out_idx_dtype=torch.int32)
        assert p.can_run_on_and_clamp()
        ok = ns["run_testcase"](p)
    elif args.suite == "prefill":
        p = lib.TestParam(**spec)
        assert p.can_run_on_and_clamp(lib.TestTarget.SPARSE_FWD)
        ok = ns["run_test"](p)
    else:
        import quant
        extra = spec.pop("extra_format")
        spec["kvcache_layout"] = quant.KVCacheLayout.V41_FP8Sparse
        if extra:
            spec.update(extra_s_k=512, extra_topk=128, extra_block_size=64,
                        extra_kvcache_layout=(quant.KVCacheLayout.V41_FP4Sparse
                                              if extra == "fp4" else quant.KVCacheLayout.V41_FP8Sparse))
        p = lib.RawTestParamForDecode(**spec).to_test_param()
        assert p.can_run_on_and_clamp(lib.TestTarget.DECODE)
        ok = ns["test_flash_mla"](p).is_correct
    torch.npu.synchronize()
    print(f"CASE_RESULT suite={args.suite} case={i+1}/{len(cases)} pass={bool(ok)}", flush=True)
    if not ok:
        raise AssertionError(f"Numerical mismatch: {p}")
    passed += 1
    torch.npu.empty_cache()
print(f"NUMERICS_PASS suite={args.suite} passed={passed}", flush=True)
