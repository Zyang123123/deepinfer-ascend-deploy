import torch
import torch_npu
from deepinfer.shared_memory import SharedTorchMemoryPool
from deepinfer.utils import try_concat
print('CREATE_POOL',flush=True)
pool=SharedTorchMemoryPool(1024*1024)
x=pool.buffer[:1024]
x.fill_(17)
print('COPY_POOL',x.is_pinned(),x.device,flush=True)
y=try_concat([x.reshape(32,32)])
torch.npu.synchronize()
assert torch.equal(y.cpu(),x.reshape(32,32))
print('SHM_COPY_PASS',flush=True)
del x,y
pool.close()
