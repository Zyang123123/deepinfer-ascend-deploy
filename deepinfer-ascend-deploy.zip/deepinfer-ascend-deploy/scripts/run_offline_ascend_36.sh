#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source /usr/local/Ascend/cann/set_env.sh
source /opt/openEuler/gcc-toolset-14/enable
export PATH="$(pwd)/scripts/toolchain:$PATH"
python scripts/toolchain/prepare_headers.py
export DG_BISHENG_GCC_TOOLCHAIN=/opt/openEuler/gcc-toolset-14/root/usr
export DG_BISHENG_COMPAT_INCLUDE="$PWD/build/bisheng-gcc14-compat"
export DEEPINFER_ACCELERATOR=ascend
export DEEPINFER_HF_MODEL_DIR="${DEEPINFER_HF_MODEL_DIR:-/home/weights/DeepSeek-V4.1-Flash-1017}"
export HF_HUB_OFFLINE=1
export DEEPINFER_ASCEND_ENGRAM_CPU_STAGING=1
export ASCEND_LOCAL_COMM_RES='{"version":"1.3"}'
export HCCL_OP_EXPANSION_MODE=CCU_SCHED
export HCCL_SOCKET_IFNAME="${HCCL_SOCKET_IFNAME:-enp34s0f1}"
export GLOO_SOCKET_IFNAME="${GLOO_SOCKET_IFNAME:-$HCCL_SOCKET_IFNAME}"
export HCCL_CONNECT_TIMEOUT=1200
export HCCL_DETERMINISTIC=true
export HCCL_IF_IP="${HCCL_IF_IP:-192.168.45.36}"
export OMP_PROC_BIND=false
export OMP_NUM_THREADS=10
export DEEPINFER_OVERRIDE_NUM_EXTRA_EXPERTS=0
# DeepInfer's Ascend Engram backend does not implement vLLM CPU offload.
# Keep the example's short context and small batch for this smoke test.
test -s /etc/hccl_rootinfo.json
mkdir -p logs
log="logs/offline-$(date +%Y%m%d-%H%M%S).log"
python -u examples/offline_inference.py --model_name "$DEEPINFER_HF_MODEL_DIR" --ep 8 --dp 8 --disable_eplb --max_num_batched_tokens 4096 --gpu_memory_utilization 0.95 --seed 1024 "$@" 2>&1 | tee "$log"
