#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/.."
source /usr/local/Ascend/cann/set_env.sh
source /opt/openEuler/gcc-toolset-14/enable
export PATH="$(pwd)/scripts/toolchain:$PATH"
export FLASH_MLA_CXX="$PWD/scripts/toolchain/flashmla-cxx"
export DEEPINFER_ACCELERATOR=ascend
python scripts/toolchain/prepare_headers.py
bash build.sh
