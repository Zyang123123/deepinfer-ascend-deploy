from pathlib import Path
src = Path("/opt/openEuler/gcc-toolset-14/root/usr/include/c++/14/bits/stl_pair.h")
s = src.read_text()
needle = "      pair& operator=(const pair&) = delete;"
assert s.count(needle) == 1, "Unsupported libstdc++ header; revalidate the bisheng workaround"
out = Path(__file__).resolve().parents[2] / "build/bisheng-gcc14-compat/bits/stl_pair.h"
out.parent.mkdir(parents=True, exist_ok=True)
patched = s.replace(needle, "      // bisheng device parser: omit redundant deleted fallback copy assignment.")
if not out.exists() or out.read_text() != patched:
    out.write_text(patched)
