import torch
import torch_npu
from torch_npu.contrib import transfer_to_npu
for n in [0,1,128]:
 for pinned in [False,True]:
  for nonblocking in [False,True]:
   print('COPY',n,pinned,nonblocking,flush=True)
   x=torch.empty((n,),dtype=torch.float32,pin_memory=pinned)
   y=x.to('npu:0',non_blocking=nonblocking)
   torch.npu.synchronize()
   print('PASS',flush=True)
