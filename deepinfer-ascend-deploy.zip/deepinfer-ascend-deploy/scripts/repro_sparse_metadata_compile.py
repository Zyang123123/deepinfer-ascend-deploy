from pathlib import Path
import subprocess,shlex
s=Path('logs/offline-36-multi-flashfix.log').read_text()
line=next(x for x in s.splitlines() if x.startswith('cd /root/.dj/tmp/') and 'kernel.asc' in x)
base=shlex.split(line.split(' && ',1)[1].removesuffix(' 2>&1'))
source=Path('/tmp/sparse_metadata_repro.asc')
source.write_text('#include <deep_gemm/sparse_mqa_logits_metadata.hpp>\nusing namespace deep_gemm::sparse_mqa_logits_metadata;\nstatic void __instantiate() { auto p = reinterpret_cast<void*>(&sparse_mqa_logits_metadata<8,56,28,8>); }\n')
base=[str(source) if a.endswith('/kernel.asc') else a for a in base]
for name,cores,schedule in [('uint32_cores28',28,8),('uint32_cores32',32,8)]:
 source.write_text('#include <deep_gemm/sparse_mqa_logits_metadata.hpp>\nusing namespace deep_gemm::sparse_mqa_logits_metadata;\nstatic void __instantiate() { auto p = reinterpret_cast<void*>(&sparse_mqa_logits_metadata<8,56,'+str(cores)+','+str(schedule)+'>); }\n')
 args=base[:-2]+['-o','/tmp/sparse_metadata_'+name+'.o']
 with open('logs/repro-sparse-'+name+'.log','w') as out:
  r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 print(name,r.returncode,flush=True)
