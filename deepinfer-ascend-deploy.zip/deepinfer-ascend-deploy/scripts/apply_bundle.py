#!/usr/bin/env python3
"""Check/apply version-pinned compatibility patches and install reusable helpers."""
import argparse
from datetime import datetime
from pathlib import Path
import shutil
import subprocess

BASES = {
    '.': ('9bd9cf243fc53ef9afbf8f04d391d989117d6ab9', 'main.patch'),
    'vendor/DeepEP-Ascend': ('3b25377d04b24fc6154698ded78a2bcb2c59afff', 'DeepEP-Ascend.patch'),
    'vendor/DeepGEMM-Ascend': ('3a35326271b069b8b5bf1a754435acd6cc91575b', 'DeepGEMM-Ascend.patch'),
    'vendor/DeepSelect': ('bfa4507d935f17ebfc3d0f00ff7d3c9a4d0e5c18', 'DeepSelect.patch'),
    'vendor/FlashMLA': ('2e5429fc5653bab6e081f09477126f731882a6a9', 'FlashMLA.patch'),
}


def git(root, *args, check=True):
    return subprocess.run(['git', '-C', str(root), *args], text=True,
                          capture_output=True, check=check)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--overwrite-scripts', action='store_true')
    args = parser.parse_args()
    root = args.repo.resolve()
    bundle = Path(__file__).resolve().parents[1]
    plan = []
    for relative, (revision, patch_name) in BASES.items():
        checkout = root / relative
        current = git(checkout, 'rev-parse', 'HEAD').stdout.strip()
        if current != revision:
            raise SystemExit(f'{relative}: revision mismatch {current}; expected {revision}. Port manually.')
        patch = bundle / 'assets' / 'patches' / patch_name
        forward = git(checkout, 'apply', '--check', str(patch), check=False)
        reverse = git(checkout, 'apply', '--reverse', '--check', str(patch), check=False)
        if forward.returncode == 0:
            state = 'apply'
        elif reverse.returncode == 0:
            state = 'already applied'
        else:
            raise SystemExit(f'{relative}: patch conflicts/partially applied\n{forward.stderr}')
        print(f'{relative}: {state}')
        plan.append((checkout, patch, state))
    files = [p for p in (bundle / 'scripts').rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.suffix != '.pyc' and p.name != 'apply_bundle.py']
    conflicts = []
    for src in files:
        dst = root / 'scripts' / src.relative_to(bundle / 'scripts')
        if dst.exists() and dst.read_bytes() != src.read_bytes():
            conflicts.append(dst)
    if conflicts:
        print('Different existing scripts:\n' + '\n'.join(map(str, conflicts)))
        if args.apply and not args.overwrite_scripts:
            raise SystemExit('No changes made. Review differences or use --overwrite-scripts (backup enabled).')
    if not args.apply:
        print('Check complete; no files modified. Use --apply to install.')
        return
    for checkout, patch, state in plan:
        if state == 'apply':
            git(checkout, 'apply', str(patch))
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = root / 'logs' / f'skill-script-backup-{stamp}'
    for src in files:
        relative = src.relative_to(bundle / 'scripts')
        dst = root / 'scripts' / relative
        if dst.exists() and dst.read_bytes() == src.read_bytes():
            continue
        if dst.exists():
            old = backup / relative
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, old)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if dst.suffix == '.sh' or relative.parts[0] == 'toolchain':
            dst.chmod(dst.stat().st_mode | 0o111)
    print('Applied. Rebuild required; no packages installed or NPU jobs started.')


if __name__ == '__main__':
    main()
