from pathlib import Path
import sys
import torch
import torch_npu
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'vendor/DeepGEMM-Ascend/tests'))
from test_attention import run_sparse_mqa_logits_case
for q,fp4,block in [(513,False,8),(513,True,16),(4096,True,8),(4096,False,16)]:
 torch.manual_seed(2026)
 run_sparse_mqa_logits_case(32,fp4,False,q,512,block,64,True,num_repeats=2)
 torch.npu.synchronize()
 print(f'SPARSE_MQA_CASE_PASS q={q} fp4={fp4} block={block}',flush=True)
print('SPARSE_MQA_NUMERICS_PASS cases=4',flush=True)
