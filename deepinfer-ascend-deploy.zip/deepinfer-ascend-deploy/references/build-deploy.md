# 构建与部署操作

先读 environment.md。以下指令在 Linux 目标机/容器执行，代理隧道单独注明本机执行。

## 1. SSH 反向代理

服务器不能直连外网、本机代理监听 7890 时，在本机保持 SSH 会话：

```bash
ssh -NT -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 \
  -o ServerAliveCountMax=3 -R 127.0.0.1:17891:127.0.0.1:7890 root@192.168.45.36
```

使用交互认证/SSH key，不把密码写进 skill、脚本或命令行。已有隧道占用端口先检查，不重复启动。
在使用 host 网络的容器内：

```bash
export http_proxy=http://127.0.0.1:17891
export https_proxy=$http_proxy
export HTTP_PROXY=$http_proxy HTTPS_PROXY=$https_proxy
export no_proxy=localhost,127.0.0.1,192.168.45.36
curl -I --connect-timeout 10 https://github.com
python -m pip config debug
```

7890 必须支持 HTTP CONNECT；如果实际是纯 SOCKS 端口，应选择正确协议并准备客户端支持。bridge 网络容器的 localhost 不是宿主，不能照抄 host 网络用法。隧道只绑定 loopback，无需开放外部代理端口。
网络超时先查 SSH 进程、监听、代理本身及 DNS；不能把 pip 下载失败当作 C++ 编译错误。

## 2. 获取固定基线

```bash
git clone --recursive https://github.com/deepseek-ai/DeepInfer.git
cd DeepInfer
git checkout 9bd9cf243fc53ef9afbf8f04d391d989117d6ab9
git submodule update --init --recursive
git submodule status
```

仅在新克隆目录 checkout。已有修改先保存 diff/版本，不对既有工作树执行 reset/clean。
校验 assets/revisions.txt 的四个 Ascend 子模块 SHA。分支后来更新时本补丁可能不适用，不能强行用 `git apply --reject` 拼凑通过。

## 3. 安装补丁与脚本

将完整 skill 文件夹传到目标机，可放在与源码并列的目录：

```bash
python /path/to/deepinfer-ascend-deploy/scripts/apply_bundle.py --repo "$PWD"
python /path/to/deepinfer-ascend-deploy/scripts/apply_bundle.py --repo "$PWD" --apply
```

默认只检查；全部补丁预检完成后才开始应用。若部分补丁已经应用，其 reverse check 会识别并跳过。异版本、部分冲突停止；不会自动回滚其他人的改动。
脚本复制存在内容冲突时默认拒绝，可审查后显式加 `--overwrite-scripts`；旧文件保存在 logs/skill-script-backup-*。

## 4. GCC14 + bisheng 构建

```bash
source /usr/local/Ascend/cann/set_env.sh
source /opt/openEuler/gcc-toolset-14/enable
export PATH="$PWD/scripts/toolchain:$PATH"
export FLASH_MLA_CXX="$PWD/scripts/toolchain/flashmla-cxx"
export DEEPINFER_ACCELERATOR=ascend
python scripts/toolchain/prepare_headers.py
which gcc g++ bisheng
g++ --version
bash -o pipefail -c 'bash scripts/build_ascend_local.sh 2>&1 | tee build.log'
```

build_ascend_local.sh 调用原仓根 build.sh：安装 requirements-ascend.txt、build_vendor.sh、构建主项目。
保留退出码。若需要确认没有旧 object 复用，优先使用干净新 checkout；对旧仓先查看各组件 build 目录，再将确定的构建产物移到备份目录后重编，不删除源码/模型或整个缓存。
库导入验证须检查实际路径：

```bash
python -c 'import deep_ep,deep_gemm,flash_mla; print(deep_ep.__file__); print(deep_gemm.__file__); print(flash_mla.__file__)'
```

`.asc` 用 bisheng，host PyTorch bindings 用 GCC14；只换系统 gcc 默认版本不够。
JIT 会用绝对 bisheng 路径而绕开 PATH 包装器，所以运行时也要：

```bash
export DG_BISHENG_GCC_TOOLCHAIN=/opt/openEuler/gcc-toolset-14/root/usr
export DG_BISHENG_COMPAT_INCLUDE="$PWD/build/bisheng-gcc14-compat"
```

本包只生成仓库内 stl_pair.h 兼容副本，不编辑 /usr/include 或 GCC 安装目录。needle 不匹配时停止重新分析，不放宽 assert。

## 5. 本机拓扑与运行环境

```bash
export DEEPINFER_ROOT="$PWD"
export HCCL_IF_IP=192.168.45.36
export HCCL_SOCKET_IFNAME=enp34s0f1
export GLOO_SOCKET_IFNAME=$HCCL_SOCKET_IFNAME
export ASCEND_LOCAL_COMM_RES='{"version":"1.3"}'
export HCCL_OP_EXPANSION_MODE=CCU_SCHED
export HCCL_CONNECT_TIMEOUT=1200
export HCCL_DETERMINISTIC=true
export OMP_PROC_BIND=false OMP_NUM_THREADS=10
export DEEPINFER_ASCEND_ENGRAM_CPU_STAGING=1
export DEEPINFER_OVERRIDE_NUM_EXTRA_EXPERTS=0
export DEEPINFER_FORCE_LOAD_BALANCE=0
test -s /etc/hccl_rootinfo.json
ip addr show "$HCCL_SOCKET_IFNAME"
```

hccl_rootinfo.json 在本平台描述 version=2.0、rank_count=8、设备/EID、网络层及 topo_file_path。由本机已验证的拓扑工具/设备配置提供，不能根据 IP 猜 EID。此前 .36 的 topo_file_path 为 driver/topo/950/atlas_850_1.json。
它不等于 PD 分离部署配置：PD 分离还需 prefill/decode 实例、KV 传输等应用配置。950 UB 通信会显式依赖这些拓扑信息；910C 上没有明显感知不表示同样的 950 拓扑文件可省略，可能是版本/传输路径/配置生成方式不同。本次没有证明 910C 的具体隐式生成机制。

## 6. 验证后启动

按 validation.md 完成相应数值检查，然后：

```bash
export DEEPINFER_HF_MODEL_DIR=/home/weights/DeepSeek-V4.1-Flash-1017
bash scripts/run_offline_ascend_36.sh
python scripts/run_benchmark_suite.py
```

运行脚本保留历史命名 `_36`，网络参数现在可由环境覆盖。离线模型路径需要所有权重、tokenizer、配置可读；HF_HUB_OFFLINE=1 只避免联网，不补全缺失文件。
本包复现离线入口；不声称提供 DeepInfer HTTP server 或将 vLLM 服务压测结果视作相同后端结果。
