# 环境、镜像和容量基线

## 实测成功环境（2026-10-26 再核对）

| 项目 | 数值 |
|---|---|
| 历史服务器/容器 | 192.168.45.36 / dsv4.1_deepinfer |
| NPU | 8×Ascend950DT，28 AIC / 56 AIV，每卡物理 HBM 96 GiB |
| 运行时可见容量 | 历史 torch 查询每卡 91.75 GiB；与物理 HBM 不同口径 |
| CPU | Kunpeng 950 7590，2 sockets×96 cores，2 threads/core，384 逻辑 CPU，最高 2.3 GHz，4 NUMA |
| 主存 | 约 1.5 TiB；swap 31 GiB，不作为 HBM 扩容 |
| 宿主内核 | 6.6.0-159.4.10.164.oe2403sp4.aarch64 |
| 容器 OS | openEuler 24.03 LTS-SP4 aarch64 |
| 驱动/npu-smi | 25.6.rc1 |
| CANN | 9.2.0；hccl、hcomm、bisheng-compiler 均为 9.2.0 |
| bisheng 报告 | clang 15.0.5，构建时间 2026-09-29；不能据此误认为 GCC 15 |
| GCC | gcc-toolset-14，14.3.1-18.oe2403sp4.aarch64 |
| Python | 3.12.13 |
| PyTorch | torch 2.13.0+cpu + torch_npu 2.13.0rc1 |
| 其他 | transformers 4.50.0，numpy 2.3.5，pybind11 3.0.1，ninja 1.13.0 |
| 模型 | /home/weights/DeepSeek-V4.1-Flash-1017，text_config.max_position_embeddings=1048576，YaRN factor=16，original=65536 |
| 仓库 | /mnt/nfs_share/home/j00930424/DeepInfer；主提交及子模块见 ../assets/revisions.txt |
| 网络接口 | enp34s0f1；示例 IP 192.168.45.36，换机器必须覆盖 |

镜像标签：`quay.io/ascend/vllm-ascend:v0.30.0rc2-a5-openeuler`。

镜像仓库 digest：
`quay.io/ascend/vllm-ascend@sha256:2fb630483fee3ee74c882ad490e2f2586e683a507b8365306f8d25e4df3e33ea`

本地 image ID：`sha256:6d0b1dd97cbacf336c7e4211b48aefd49aa8580c0907b29871a439d8cec8567a`。
image ID 是本地配置摘要，不可当作仓库 manifest digest 拉取。
后续 GCC14、源码构建和兼容修改在容器可写层，未确认存在可直接拉取的“修复完成镜像”；必须执行构建步骤。

## 缺少环境时安装或启用

在该 openEuler 包源可用的前提下：

```bash
dnf install -y gcc-toolset-14-gcc gcc-toolset-14-gcc-c++ \
  gcc-toolset-14-libstdc++-devel git cmake ninja-build
source /opt/openEuler/gcc-toolset-14/enable
gcc --version
g++ --version
source /usr/local/Ascend/cann/set_env.sh
python --version
bash /usr/local/Ascend/cann/query_pkg_version.sh
```

包源没有上述版本时，获取与 openEuler 24.03 SP4 aarch64 匹配的软件包，不把其他发行版 RPM 混装。
Python 不是 3.12 时优先使用上述经过匹配的镜像，而不是替换系统 `/usr/bin/python`。
CANN 缺失时使用本地获准分发的 aarch64 CANN 9.2 toolkit/ops 安装包；先执行各安装包 `--help`，根据该包支持的 `--install`/`--install-path` 选项安装并 source set_env.sh。本项目没有提供安装包或验证过的公开下载链接，不能编造下载地址。
宿主驱动/固件由设备维护人员按 CANN 兼容矩阵部署，不在运行中替换；镜像内装 CANN 不等于升级宿主驱动。

`requirements-ascend.txt` 指定 torch 2.13.0+cpu、torch-npu 2.13.0rc1 并引用 requirements-dev.txt。运行仓库 build.sh 会安装 Python 依赖。离线环境需准备全部 aarch64/Python3.12 wheels 及构建依赖，用 `PIP_FIND_LINKS`、`PIP_NO_INDEX=1` 指向已验证 wheelhouse；不要只拷贝 x86 wheel。

## 容器资源与创建示例

历史容器为 privileged=true、network=host、pid=host、ipc=shareable、shm-size=500 GiB。
设备映射：davinci0..7、davinci_manager、hisi_hdc、ummu、uburma。
历史还绑定了 /usr/lib64、/mnt、/lib/route.conf、driver、/usr/local/sbin、npu-smi、/etc/hixlep、/var/log/npu→/usr/slog、/root/host、/home、dcmi、/data。
这是历史配置，不说明所有绑定都不可缺少。尤其 /usr/lib64 覆盖容器库会影响 ABI，只有核实匹配时复用。

以下为同类机器的起点，路径先核实；不是已运行过的全新容器验收证明：

```bash
IMAGE='quay.io/ascend/vllm-ascend@sha256:2fb630483fee3ee74c882ad490e2f2586e683a507b8365306f8d25e4df3e33ea'
devices=()
for d in /dev/davinci{0..7} /dev/davinci_manager /dev/hisi_hdc /dev/ummu /dev/uburma; do
  test -e "$d" || { echo "missing device: $d"; exit 1; }
  devices+=(--device "$d")
done
docker run -dit --name deepinfer-repro --privileged --network host --pid host \
  --ipc shareable --shm-size 500g "${devices[@]}" \
  -v /mnt:/mnt -v /home:/home \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro \
  -v /usr/local/dcmi:/usr/local/dcmi:ro \
  -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi:ro \
  -v /etc/hccl_rootinfo.json:/etc/hccl_rootinfo.json:ro \
  "$IMAGE" bash
```

示例假设宿主已有正确的本机 `/etc/hccl_rootinfo.json` 和 npu-smi 路径；实际历史 rootinfo 在容器内，不能据此假定宿主一定有。容器内验证 npu-smi、动态链接依赖、HCCL 拓扑和设备权限后再跑测试。
500 GiB /dev/shm 是容量上限而非立刻占满；历史多模态共享池默认每 rank 8 GiB，共约 64 GiB pinned host memory，另需 Engram staging 主存。

## 较早的容量不足环境

192.168.45.34 历史审计：物理 84 GiB，AI pool 68.25 GiB，差额 15.75 GiB；不是 .36 的 96/91.75 GiB。
证据见 ../assets/evidence/memory-audit-summary.json。未完整识别所有排除区域的归属，未找到受支持的在线调整接口，也未重置设备/修改固件/释放系统内存池。
缩短上下文可降低 KV/cache/临时量，不能缩小模型常驻权重和 Engram 最低占用；若启动阶段就超容量，单靠改上下文或 utilization=0.95 不保证解决。

### 使用随包启动脚本（用户提供版本）

在宿主机解压补丁包后执行：

```bash
IMAGE='quay.io/ascend/vllm-ascend:v0.30.0rc2-a5-openeuler'
docker pull "$IMAGE"
bash deepinfer-ascend-deploy/scripts/docker_start.sh "$IMAGE" dsv4.1_deepinfer
docker exec -it dsv4.1_deepinfer bash
```

已有同名容器直接进入，不重复创建。脚本需要镜像和容器名两个参数，源自用户提供的 `/mnt/nfs_share/home/j00930424/docker_start.sh`。修正了参数提示、变量引用和重复 npu-smi 挂载；原文见 `assets/docker_start.original.sh`。该脚本没有挂载 hccl_rootinfo.json，需在当前机器生成或配置后检查；未重新执行容器创建验证。