# 数值、功能与性能验证

## 状态说明

历史验证在 .36 已完成；skill 打包期间未占用正在使用的 NPU。新机器必须重跑相关检查。
assets/evidence 同时包含成功和故障定位日志，文件名含 staging2、mega-moe 的并非成功证明。
共享路径和模型形状 DeepEP 的 `.exit` 文件为0；输出有 Testing 不代表单独已通过，需结合退出码。

## 环境初始化

```bash
cd /path/to/DeepInfer
source /usr/local/Ascend/cann/set_env.sh
source /opt/openEuler/gcc-toolset-14/enable
export PATH="$PWD/scripts/toolchain:$PATH"
export DEEPINFER_ACCELERATOR=ascend
export DG_BISHENG_GCC_TOOLCHAIN=/opt/openEuler/gcc-toolset-14/root/usr
export DG_BISHENG_COMPAT_INCLUDE="$PWD/build/bisheng-gcc14-compat"
python scripts/toolchain/prepare_headers.py
```

单卡算子也需要确认该卡可用。多卡测试前设置 build-deploy.md 的本机网络环境，检查 npu-smi，停止已有服务必须有针对它的授权。

## 单卡数值回归

```bash
python scripts/test_ascend_numerics.py select
python scripts/test_ascend_numerics.py prefill
python scripts/test_ascend_numerics.py decode
python scripts/test_sparse_mqa_compat.py
python scripts/test_deepgemm_sf_compat.py
```

- select：脚本定义24配置，复用上游参考/tolerance；本包未收集对应最终成功日志，不额外宣称24全部通过。
- prefill：24/24；decode：48/48，证据末尾 NUMERICS_PASS。
- sparse MQA：4/4，末尾 SPARSE_MQA_NUMERICS_PASS。
- SF布局脚本测试 dtype/major/granularity/batch和ragged尺寸；本包附可复用脚本，但未收集完整最终日志，运行后记录实际通过数，不凭源码循环数宣称成功。

## DeepEP 多端点

```bash
bash scripts/run_multi_endpoint_test_36.sh vendor/DeepEP-Ascend/tests/ep/test_ep.py \
  --num-processes 8 --num-tokens 128 --hidden 5120 --num-topk 6 \
  --num-experts 384 --skip-perf-test
bash scripts/run_multi_endpoint_test_36.sh vendor/DeepEP-Ascend/tests/engram/test_engram.py \
  --num-processes 8 --num-qps 0
bash scripts/run_multi_endpoint_test_36.sh vendor/DeepEP-Ascend/tests/engram/test_engram.py \
  --num-processes 8 --num-qps 0 --use-fp8
```

模型形状历史测试18种dispatch/combine组合；BF16/FP8 Engram成功日志附包。
共享端点回归只能在实际共享端点拓扑上复测，不伪造endpoint以命中分支。历史共享回归日志和退出码附包。
改通信代码后需重编 DeepEP，不只重新运行 Python。

## CPU staging与输入复制

脚本：test_engram_cpu_staging.py、test_npu_input_copy.py、test_npu_shm_copy.py。
已完成环境初始化且设备空闲时，可运行：

```bash
python scripts/test_npu_input_copy.py
python scripts/test_npu_shm_copy.py
bash scripts/run_multi_endpoint_test_36.sh scripts/test_engram_cpu_staging.py --num-processes 8 --num-qps 0
bash scripts/run_multi_endpoint_test_36.sh scripts/test_engram_cpu_staging.py --num-processes 8 --num-qps 0 --use-fp8
```

input_copy 只证明不同长度/pinned/nonblocking组合能完成复制，使用 empty 输入不能作为数值一致性证明；shm_copy 则以17填充并逐元素比较。
test-36-staging2.log 是在多端点修复前失败的证据，不能列入通过清单；staged shared-memory复制成功证据单独保存。

## 离线功能

```bash
bash scripts/run_offline_ascend_36.sh
```

历史完整离线功能成功（180条文本/图像、14327输出token为会话记录），本包未附该完整功能日志，独立复现应生成新日志并验证输出。
仅看退出码不能确认回答质量；若需要数学精度，另做非重复GSM8K标准问答和答案评分，不能使用本包固定长度性能结果代替。

## 性能基线与尚未执行用例

2026-10-23固定批：GSM8K 200请求、4096输入/2048输出、最大并发200：9635.678 TPS，TTFT平均7.284087秒，P95 12.912739秒，单卡测量HBM最高93.645508 GiB，无新JIT；英文基线11299.460 TPS。
这两轮不是400请求闭环；不要把这组数填到新套件。

新套件为4K+2K/400/200、64K+1K/48/12、128K+1K/32/8；截至2026-10-26，CPU单测5项通过，脚本部署成功，但用户要求保留满载vLLM，仍等待空闲。
开始前重新检查并发任务。完成后核对请求数、实际token数、峰值在途并发、NPU worker快照、HBM和JIT audit。任何用例失败保留failure/log及部分完成JSONL，不编造整轮成功指标。

## 本包本地检查

```bash
python -m unittest discover -s scripts -p test_configurable_benchmark.py -v
python -m py_compile scripts/benchmark_configurable.py scripts/run_benchmark_suite.py scripts/apply_bundle.py
```

skill元数据验证不等于驱动/内核数值验证；必须分别报告。
