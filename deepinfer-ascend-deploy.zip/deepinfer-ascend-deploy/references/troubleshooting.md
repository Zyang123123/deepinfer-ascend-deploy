# 故障、原因与修复索引

以下来自当前会话、保存的源码 diff 与日志。没有精确日志证明的底层原因标为推断/未完全确认；不把所有报错都归为 CANN 缺陷。补丁文件见 assets/patches。

## 网络与构建

### pip/git 下载超时、代理断开

原因：服务器无代理，或本机 SSH 反向转发已断开；容器网络命名空间影响 localhost。
处理：重建 loopback 17891→本机7890 隧道，在 host-network 容器设置 http(s)_proxy，curl 测通后再构建。只重跑失败步骤并保留日志。绝不把密码写入 pip 配置。

### GCC 不满足 >=13 的前置要求

处理：安装并 source gcc-toolset-14；同时检查 g++、include 搜索路径和链接到的 libstdc++。本环境精确包版本在 environment.md。
原始前置条件是 Linux、GCC>=13、Python3.12、Ascend CANN9.2。镜像自带编译器不自动满足它。

### bisheng 与 GCC14 标准库、PyTorch host headers 不兼容

现象：采用新标准库后，bisheng 对 C++20 std::pair copy assignment 的解析冲突；仅升级 GCC 未解决。
原因定位：设备编译前端与 GCC14 header 的语法兼容性，而非算术算法问题。
修复：`scripts/toolchain/prepare_headers.py` 从固定 GCC14 stl_pair.h 生成仓库内副本，只去掉冗余 deleted fallback `pair& operator=(const pair&) = delete;`；精确匹配一次才修改。`bisheng` 包装器显式 `--gcc-toolchain`，仅 .asc 添加兼容 include。
FlashMLA `setup.py` 允许 FLASH_MLA_CXX；`flashmla-cxx` 对 .asc 调 bisheng，对 host C++ 调 GCC14 并过滤设备专有参数。
边界：不是替换整个 libstdc++，不降低 C++ 标准，不禁用数值检查。不同 GCC header 必须重新验证。

### DeepGEMM JIT 又选回旧标准库

原因：JIT 调用绝对路径 bisheng，PATH 中包装器不起作用。
修复：DeepGEMM `csrc/jit/jit.hpp` 读取 DG_BISHENG_GCC_TOOLCHAIN、DG_BISHENG_COMPAT_INCLUDE，追加到实际 JIT 编译选项；运行脚本导出两者。
重编扩展并检查运行时新 kernel 编译日志，而非只看构建时 which bisheng。

### DeepSelect std::format、CANN 未公开符号/头文件

- DeepSelect `csrc/api.cpp` 中错误文本的 std::format 改为 TORCH_CHECK 可变参数拼接，保持相同 stride/alignment 断言，不修改 top-k 算法。
- DeepGEMM ascend.hpp 显式 include `<utils/debug/asc_assert.h>`，补全断言声明来源。
- FlashMLA `asc_float2bfloat16_rn_v2_impl` 替换为公开 `asc_float2bfloat16_rn_v2`；保留 v2 lane 布局，不擅自换成语义不同的转换。
验证：DeepSelect 上游参考测试及 FlashMLA prefill/decode 数值回归。

### sparse MQA metadata JIT 编译器崩溃

原因定位：CANN9.2 对该 SIMT 64-bit loop induction lowering 崩溃，不是 shape 越界导致的运行时错误。
修复：`sparse_mqa_logits_metadata.hpp` 两处循环采用 uint32_t，并用 `min(step, end-current)` 收敛增量，避免末端加法溢出；不只是删除 uint64_t。
验证：`repro_sparse_metadata_compile.py` 定位编译问题，`test_sparse_mqa_compat.py` 四种数值配置通过（含 4096 query、FP4/FP8、block8/16）。
其中 repro_sparse_metadata_compile.py 是历史诊断辅助脚本，依赖当时的 logs/offline-36-multi-flashfix.log 和 JIT 编译命令/缓存路径；新机器不可直接运行，需先用自己的失败日志与仍存在的 include/源码路径替换。正常复现优先使用独立的 test_sparse_mqa_compat.py，不依赖这份历史日志。

## 通信适配

### HCCL 网络层数量断言、硬编码 layer1

原因：原实现假设 `num_layers>1` 且 `layers[1]` 支持所需协议；本机拓扑可能只提供 layer0。
修复：DeepEP 和 DeepGEMM 遍历候选 layer，检查对每个 peer 的协议连通性；先拷贝 HCCL 持有的 layer 数组，再进行后续查询，避免底层返回存储失效。
普通 EP 要 UB_MEM+UBC_CTP，UBMEM-only 路径只要求 UB_MEM。没有合适 layer 时清晰失败，不能强选 layer0。

### `multiple local UBC_CTP endpoints are not supported`

原因：950DT 本机每个 rank 对不同 peer 暴露不同 local EID，原实现要求所有 peer 共享一个 local endpoint。本机未找到可用的共享端点配置，不能改文件伪造共享 EID。
修复：DeepEP `hccl.hpp` 检测 shared_endpoint；共享路径保留，多端点走 `acquire_multi_endpoint_jetties`。每个 `(AIV, peer)` 独立 endpoint、注册内存、队列和 port 交换。设备 handle、barrier、dispatch/combine、bucket/PP 访问随 peer 正确索引。
在 56 AIV、EP8 下为 56×7=392 个 channel/rank；`num_aiv_queues` 与 endpoint 总数分开，不能把 392 当 AIV 核数。
设备表前置 stride header，并在析构时释放原始分配地址；保持 shared stride=0 的旧语义。
验证：模型形状 tokens128、hidden5120、topk6、experts384，18 dispatch/combine 组合；共享端点回归；Engram BF16/FP8。

### 多端点扩展后的队列资源、子通信组初始化问题

原因定位：Engram fetch 只需 UBMEM，仍分配 CTP 队列会额外消耗资源；新子组尚未执行 collective 时，分配 AIV 队列后再初始化协商流也可能失败。
修复：Engram Context 传 use_jetties=false，允许0队列；多端点分配前执行 gather_listen_ports 预热协商 collective/stream。
边界：不能给普通 EP 也关闭 CTP。不能通过无限增加超时解决资源或 endpoint 语义错误。

### rootinfo 文件看似只在 PD 部署出现

本机文件是 HCCL rank graph/topology 输入，不是完整 PD 配置。DeepEP 单机 EP 通信也会用到。910C 与950的网络栈和拓扑机制不同，本次没有验证 910C 隐式来源；不要把这个文件解释成“只用于 PD 分离的权重/缓存配置”。

## 算子回退与设备差异

### FlashMLA 假设32核，实机28核

现象：AI core count 不匹配断言。
修复：去掉固定 GRID_SHAPE=32；query 调度步长和 launch num_ctas 同时使用 params.num_sm，校验正数。
原因：只修改断言或 launch，而保留 stride32，会遗漏工作；不是简单“让断言通过”。
验证：prefill24 + decode48，共72用例，含可变长度、sink及扩展 FP8/FP4 KV。

### MegaMoE 不兼容28核 → 普通 MoE

原因：当前 MegaMoE workspace 与调度硬编码32 AI cores；模型 fp8×fp4 在原条件下选中了它。
修复：主仓 mlp.py 的 use_mega_moe 对 Ascend 加 `deep_gemm.get_num_sms()==32` 条件，28核使用普通 DeepEP dispatch/combine + grouped GEMM。GPU 原有逻辑保留。
这是功能路径回退，不是把 fp8/fp4 回退为全 BF16，也不声称同等性能。不要将核数伪报成32。
数值证明以各组成算子和已完成离线推理为准；MegaMoE失败日志仍保留，不把它列为已修好的32核实现。

### host-registered shared memory 的 H2D DMA 失败

现象：共享内存输入被认为 pinned，却在异步 DMA 路径出现运行时失败/崩溃。
原因定位：本平台 CANN9.2/驱动组合不支持这一 host-registered shared-memory 直接异步传输组合；不是所有 pinned memory 都不可用。
修复：`deepinfer/utils.py::try_concat` 在 NPU 且全 CPU 输入时令 all_pinned=false，转入 torch pinned allocator staging 路径。
代价：增加 CPU 中转复制。不要全局关闭所有异步传输或改 GPU 行为；对新版驱动需重新验证是否仍需该保守路径。
复现与检查：test_npu_input_copy.py、test_npu_shm_copy.py；成功证据为 staged 路径，不把原失败路径当通过。

## 加载与显存

### Engram 加载时双份 NPU 表导致 OOM

原因：checkpoint 表先 materialize 到 NPU，再拷贝到 DeepEP Engram storage，加载期同时保留两份。
修复：主仓 deepseek.py 支持 DEEPINFER_ASCEND_ENGRAM_CPU_STAGING=1；DeepEP engram.hpp 接受 CPU contiguous storage，通过同步 HOST_TO_DEVICE 拷贝到最终表。日志增加 planned parameter storage 分类。
边界：最终表仍占 NPU；不是 vLLM Engram CPU offload，不能照搬 vLLM 的 offload 配置来推算 DeepInfer 容量。

### utilization 从0.85到0.95仍不足、15.75 GiB 系统预留

0.95 改的是引擎允许使用的比例，不能把 runtime total 之外的容量变成可用 HBM。
较早机器物理84 GiB、AI pool68.25 GiB；设备布局审计证明容量差存在，但所有区域归属未完整暴露，未找到支持的在线调整接口。
不应 reset/改固件/释放系统区冒险追求容量。改到 .36 的96 GiB卡后完成推理。
减上下文仅减少 KV/cache 等可变占用，不解决常驻权重/最终 Engram 超容量。

### 将 max_model_len 缩到6208引发 candidate top-k 断言

实际请求4K+2K与引擎内部索引结构容量不是同一概念。该基线候选块参数（2048×8相关约束）在过小 engine capacity 下失败。
已验证配置保留 max_model_len32768，同时实际 input=4096/output=2048；不伪造实际请求长度。
长请求脚本按输入+输出+MTP余量向上取整32768倍数。64K/128K新用例尚未上机通过，不能从小上下文成功推导长上下文成功。

## 测试脚本和测量故障

### 把返回的 numpy.uint64 当 RequestOutput

引擎返回对象指针句柄。必须 `RequestOutput.clone(raw_output)` 后读取字段。每个实际 token 计一次；accepted draft token 不额外重复累加到输出吞吐分子。

### 短预热导致尾部新 GEMM 编译、吞吐失真

最初仅64输出token预热未覆盖批次排空形状，正式轮发生约3次3.6秒停顿；缓存 kernel.o 时间戳与测量窗口重合。
修复：与正式输入/输出长度相同的完整预热，统计 warmup之外的测量；保存 JIT audit。
历史英文版 v3约8708 TPS不作为有效优化对比，完整预热 v4约11299 TPS。

### torch_npu profiler 自动解析失败

自动 parser 报错与推理/原始采样成功分别判断。保留原始 PROF_*；analyze_benchmark.py 在配置的容器内执行 `msprof --export=on --type=text --output=...` 后解析 op_summary。
profiler 使用独立诊断轮，不计入正式吞吐。kernel累计占比可重叠，不等于端到端占比。

### 并发混淆、其他任务启动

旧固定批200请求不等同于总400请求/并发200的闭环测试。新脚本区分总量与上限；并发12不要求被8整除，分配2/2/2/2/1/1/1/1。
GSM8K首轮测量期间另一测试启动，占NPU0；保留并标注，不将其作为独占结论。经当次用户授权停止后重测，18次快照仅本轮8个worker，无新增JIT。
当前2026-10-26的另一套 vLLM 被用户要求保留，待空闲再跑；之前停止其他任务的授权不能当作永久通行证。

### 重复题目、高MTP接受率与线上指标

GSM8K question-only重复至固定token数仍是合成长度负载，ignore_eos强制输出，未评价答案准确率。不要把99% MTP接受率推广到真实数学请求。
离线TTFT不包含HTTP/客户端网络、tokenization，单批/闭环/开环到达模式也不同。使用在线工具时须对齐 tokenizer、chat template、prefix cache、实际长度、MTP和计时边界。
