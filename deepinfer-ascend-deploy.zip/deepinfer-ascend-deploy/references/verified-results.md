# GSM8K 重复数学题：DeepInfer 离线性能测试

2026-10-23，192.168.45.36，dsv4.1_deepinfer，8×Ascend950DT。
正式结果目录：`/mnt/nfs_share/home/j00930424/DeepInfer/logs/bench-36-gsm8k-4k2k-c200-v2`。
模型：`/home/weights/DeepSeek-V4.1-Flash-1017`。

测试成功，退出码 0。200 个请求均为 4096 输入 token、2048 实际输出 token，共生成 409600 token。未发生 OOM、抢占或请求中止。

## 数据与配置

使用用户指定工具仓库中的 [GSM8K.jsonl](https://github.com/rayn-zzz/aisbench_auto_tools_prefix/blob/main/GSM8K.jsonl)，共 1319 题。
只取 question，不包含参考答案；在题目后添加两个换行，编码后重复 token 序列并截断为 4096 token。
不添加原英文版的随机 64-token 前缀，不添加 chat template。
seed=1024，随机排列后分别选择 200 题用于预热、正式测量和独立 profiling。
核验 600 个题目行号和 prompt 哈希均唯一，输入长度全部为 4096。

EP8 / DP8 / CP1，整机并发 200（每 rank 25），单次批量提交；temperature=0，ignore_eos=True，MTP=5，普通 MoE，真实路由，关闭 EPLB 重排。
显存利用率 0.95，max_model_len=32768，每 rank prefill token budget=4096。
完整 200 请求 4K/2K 预热、独立 10-step profiler 均不计入正式测量。
两版记录的 DEEPINFER/HCCL/ASCEND/OMP 环境配置一致。

## 与此前英文版对比

| 指标 | 英文版 v4 | GSM8K v2 |
|---|---:|---:|
| 整批耗时，秒 | 36.250 | 42.509 |
| 总输出吞吐，token/s | 11299.46 | 9635.68 |
| 平均 TTFT，秒 | 7.324 | 7.284 |
| P50 TTFT，秒 | 7.321 | 7.285 |
| P95 TTFT，秒 | 12.947 | 12.913 |
| P99 TTFT，秒 | 13.458 | 13.424 |
| 满并发 decode 窗口吞吐，token/s | 18176.46 | 15061.34 |
| 单请求平均 decode TPS | 72.82 | 62.36 |
| MTP draft 接受率 | 98.225% | 99.475% |
| 正式测量最高单卡 HBM，GiB | 93.958 | 93.646 |

整体输出吞吐下降约 14.72%，满并发 decode 吞吐下降约 17.14%；TTFT 基本持平。
输出吞吐分母为第一条请求提交至最后一条完成，包括 prefill、decode 和尾部排空。
TTFT 从引擎提交到首 token 返回计时，包括排队。
这是离线单批请求结果，不能等同于持续补充请求的在线并发 200 压测。

正式测量各卡 HBM 采样峰值（GiB）：
0=92.750，1=92.940，2=93.565，3=92.923，4=93.139，5=93.509，6=92.947，7=93.646。
包含预热和独立诊断的全流程最高单卡 HBM 为 94.329 GiB。
PyTorch allocated 最高 47.783 GiB，reserved 最高 49.164 GiB；其口径不包括全部 CANN/通信/系统显存。
HBM 是间隔采样峰值，可能漏掉短暂尖峰。

## 普通 MoE 耗时观察

独立 rank 0 profiler 中，MoE grouped GEMM 占累计 kernel 时间 38.58%，dispatch/combine 占 27.04%，两者合计约 65.62%。
注意：这些是 kernel 时间累加占比，存在跨 stream 重叠，不是端到端耗时占比；本轮捕获 kernel 数量也与旧轮略有差异。
为避免调用次数差异误导，比较相同 kernel 的平均耗时：

| kernel | 英文版平均，μs | GSM8K 平均，μs |
|---|---:|---:|
| MoE up grouped GEMM | 330.61 | 472.00 |
| MoE down grouped GEMM | 167.68 | 238.29 |
| 主要 combine kernel | 147.70 | 222.52 |

MTP 接受率提高，但 decode 变慢，因此不能把下降解释为投机解码接受率变差。
采样证据将重点定位到 MoE 计算和通信；题目变化可能改变专家 token 分布及实际处理量，但目前没有逐专家 token 计数和相邻英文回归轮，不能将全部差异严格归因于专家路由。
正式 decode 日志的 moe_lb 约为 1.81–1.84，与旧轮量级相近，单凭此指标不足以解释差异。
若继续优化，应采集逐层/逐专家 token 数、padding 后计算量和跨 rank 通信等待，再进行同一时间窗口内的英文/GSM8K 交替测试。

## 有效性检查与第一轮处理

第一轮 GSM8K v1 成功完成，但测量过程中另有 wyt-vllm 容器的 multirank_npu_bench_collect.py 启动；后来观察到其占用 NPU 0。
用户明确批准停止后，已向核验过的进程组 4094921 发送 SIGTERM，确认退出且 8 卡空闲，再启动本轮 v2。
v1 吞吐 9639.76 token/s，仅作为受干扰的历史记录保留，不用作正式结论。

v2 的正式测量期间共获取 18 次完整 npu-smi 快照，仅出现本次 8 个 worker PID，没有观察到外部进程。
每卡均有显存采样，最大实际 running 请求数为 200。
DeepJIT 审计确认正式测量期间无新增 kernel.o 编译。
完整原始快照保存在 npu_smi_snapshots.jsonl；occupancy_audit.json 保存本地核验结果。
进程快照是采样证据，不能证明采样间隔内绝对没有短暂任务。

## 复现与文件

将脚本包中的文件放入仓库 scripts/，在服务器执行：

```bash
docker exec -it -w /mnt/nfs_share/home/j00930424/DeepInfer dsv4.1_deepinfer \
  bash scripts/run_benchmark_36.sh --dataset scripts/GSM8K.jsonl
```

脚本自动生成新目录、完整预热、测量、独立采样并汇总结果。
它不会停止其他任务；运行前应确保 8 卡空闲。
原始结果包：bench-36-gsm8k-4k2k-c200-v2.tar.gz。
SHA256：88679360dd8c88d67b8fbaded9f1af67f84fa9286f68269ce3d106a069551d59。
数据集 SHA256：fb581f0270b25988e071316835842a1c8449f4e27af6fc0f539ef270b987f9ff。

本次仍是“重复数学题 + 强制输出 2048 token”的性能负载，不是 GSM8K 答案准确率测试。
