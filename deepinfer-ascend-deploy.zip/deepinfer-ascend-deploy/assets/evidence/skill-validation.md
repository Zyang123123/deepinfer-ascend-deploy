# Skill 打包核验：2026-10-26

- skill-creator 官方 quick_validate.py：Skill is valid。
- 目标 Linux 容器 bash -n：全部打包 shell 启动器、bisheng/flashmla-cxx 包装器通过。
- python compileall：全部打包 Python 脚本语法通过；没有执行算子或初始化 NPU。
- test_configurable_benchmark.py：5项通过，含三组请求分配、非整除并发、闭环模拟、指标公式、长上下文容量与非法容量拒绝。
- apply_bundle.py --repo 实际源码目录：主仓、DeepEP-Ascend、DeepGEMM-Ascend、DeepSelect、FlashMLA 五份补丁均识别为 already applied；未写入实际代码。
- 脚本差异预检识别4个启动器网络参数已改为可覆盖环境变量；没有覆盖现有脚本。
- 本轮仅采集环境/源码/日志并在独立 logs/skill-check-20261026 目录检查；没有停止 vLLM、重建扩展或进行新的 NPU 数值/性能测试。
- 新三组批量测试仍为待上机状态，历史固定批200请求结果不作为新用例结果。

校验器运行时所需 PyYAML 仅安装在打包工作区，未作为运行依赖加入 skill。
